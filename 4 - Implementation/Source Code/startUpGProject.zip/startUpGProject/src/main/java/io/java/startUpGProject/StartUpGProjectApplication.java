package io.java.startUpGProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StartUpGProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(StartUpGProjectApplication.class, args);
	}

}
